package com.example.urok7zm

data class Listitem (
        var image_id:Int,
        var titleText:String,
        var contentText:String
        )
